http://blog.bodurov.com/Formatter-and-Colorer-of-Raw-JSON-Code/
https://github.com/johan/QuickJSON/tree/master/json-viewer