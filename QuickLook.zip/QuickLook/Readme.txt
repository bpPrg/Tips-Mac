Author: Bhishan Poudel, Physics PhD student Ohio University
Date  :  Mar 1, 2018

Topic: MacOS QuickLook plugins
====================================
https://github.com/sindresorhus/quick-look-plugins
http://www.quicklookplugins.com/

Warning: do not use **QLColorCode**


I have used only three pluings:
/Users/poudel/Library/QuickLook/BetterZipQL.qlgenerator
/Users/poudel/Library/QuickLook/QLMarkdown.qlgenerator
/Users/poudel/Library/QuickLook/QLStephen.qlgenerator
/Users/poudel/Library/QuickLook/QuickLookJSON.qlgenerator

To activate:
qlmanage -r

If folder does not exist, create it.



For astronomers
===============
https://www.onekilopars.ec/qlfits

brew cask install qlfits
