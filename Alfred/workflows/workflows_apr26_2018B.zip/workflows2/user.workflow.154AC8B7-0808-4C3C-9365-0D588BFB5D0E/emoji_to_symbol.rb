require './emoji_symbols'
print EMOJI_SYMBOLS[ARGV.first.to_sym]
