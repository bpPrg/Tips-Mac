Packal Update Workflow
====

By Shawn Patrick Rice

This Alfred 2 workflow simply keeps your other Alfred 2 workflows that you've downloaded from http://www.packal.org up to date.