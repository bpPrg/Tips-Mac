<?php

namespace AlfredSlack\Models;

class AuthModel extends Model {

  protected $_type = 'auth';

  protected $url;
  protected $team;
  protected $user;
  protected $team_id;
  protected $user_id;

}
