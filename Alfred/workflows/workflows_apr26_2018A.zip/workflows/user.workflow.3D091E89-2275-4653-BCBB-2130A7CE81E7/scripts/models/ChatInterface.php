<?php

namespace AlfredSlack\Models;

interface ChatInterface {

}
