const alfy = require('alfy');
const input = alfy.input.toLowerCase();

alfy.config.set('theme', input);

