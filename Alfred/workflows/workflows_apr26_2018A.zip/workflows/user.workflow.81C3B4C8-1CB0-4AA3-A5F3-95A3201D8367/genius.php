<?php

use Alfred\Workflows\Workflow;

require 'vendor/autoload.php';

$workflow = new Workflow;

$url = 'http://genius.com/search/quick.js';
$params = ['q' => $query, 'limit' => 20];
$full_url = sprintf('%s?%s', $url, http_build_query($params));

$results = explode("\n", file_get_contents($full_url));

foreach ($results as $result) {
    list($item_title, $item_url, $item_id) = explode('|', $result);
    $workflow->result()->title($item_title)->arg(ltrim($item_url, '/'));
}

echo $workflow->output();
