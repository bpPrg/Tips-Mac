<?php

use Alfred\Workflows\Workflow;

require 'vendor/autoload.php';

$workflow = new Workflow;

$result = exec('/usr/bin/osascript spotify-current-track.AppleScript');

$workflow->result()->arg($result);

echo $workflow->output();
